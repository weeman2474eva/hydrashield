# HYDRA SHIELD source notice

HYDRA SHIELD is a GPLv2 derivative of OpenVPN for Android by Arne Schwabe.
The original project is https://github.com/schwabe/ics-openvpn and its full
licence terms are retained in `doc/LICENSE.txt`. The source corresponding to
every distributed HYDRA SHIELD binary must remain available under those terms.

HYDRA-specific panel UI and API integration are located in
`main/src/skeleton/java/de/blinkt/openvpn/hydra/`.

Build the `skeletonOvpn23` flavour. The release package is
`com.hydra.shield`; debug builds may use the configured debug suffix.
