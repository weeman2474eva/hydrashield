/*
 * HYDRA SHIELD - panel managed OpenVPN client.
 * Copyright (C) 2026 HYDRA SHIELD contributors.
 * GPLv2; see doc/LICENSE.txt and SOURCE_NOTICE.md.
 */
package de.blinkt.openvpn.hydra;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import de.blinkt.openvpn.LaunchVPN;
import de.blinkt.openvpn.VpnProfile;
import de.blinkt.openvpn.core.ConfigParser;
import de.blinkt.openvpn.core.ProfileManager;

public final class HydraShieldActivity extends Activity {
    private static final int BG = Color.rgb(5, 8, 14);
    private static final int PANEL = Color.rgb(14, 25, 40);
    private static final int CYAN = Color.rgb(54, 225, 255);
    private static final int BLUE = Color.rgb(0, 125, 221);
    private static final String PREFS = "hydra_shield";

    private LinearLayout root;
    private TextView status;
    private ProgressBar progress;
    private String panelUrl;
    private String token;
    private final List<Server> servers = new ArrayList<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        panelUrl = getPreferences(MODE_PRIVATE).getString("panel", "");
        token = getPreferences(MODE_PRIVATE).getString("token", "");
        if (!panelUrl.isEmpty() && !token.isEmpty()) showServers(); else showLogin();
    }

    private void base(String subtitle) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(34), dp(22), dp(34), dp(22));
        root.setBackgroundColor(BG);
        setContentView(root);
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView badge = label("⬡", 38, CYAN); badge.setGravity(Gravity.CENTER);
        TextView title = label("HYDRA SHIELD", 29, Color.WHITE); title.setTypeface(Typeface.DEFAULT_BOLD); title.setLetterSpacing(.08f);
        titleRow.addView(badge, new LinearLayout.LayoutParams(dp(58), dp(58)));
        titleRow.addView(title, new LinearLayout.LayoutParams(0, dp(58), 1));
        root.addView(titleRow);
        TextView sub = label(subtitle, 14, Color.rgb(150, 180, 202)); sub.setPadding(dp(62), 0, 0, dp(12)); root.addView(sub);
        status = label("", 15, CYAN); root.addView(status);
        progress = new ProgressBar(this); progress.setIndeterminate(true); progress.setVisibility(View.GONE); root.addView(progress, new LinearLayout.LayoutParams(-1, dp(4)));
    }

    private void showLogin() {
        base("Secure. Private. Connected.");
        LinearLayout card = card();
        TextView welcome = label("VPN ACCOUNT LOGIN", 18, CYAN); welcome.setTypeface(Typeface.DEFAULT_BOLD); card.addView(welcome);
        EditText panel = input("Panel DNS / URL", false); panel.setText(panelUrl); card.addView(panel);
        EditText user = input("Username", false); card.addView(user);
        EditText pass = input("Password", true); card.addView(pass);
        Button login = action("SIGN IN"); card.addView(login);
        TextView note = label("Enter the secure panel address supplied by your provider.", 13, Color.LTGRAY); card.addView(note);
        root.addView(card, new LinearLayout.LayoutParams(-1, -2));
        login.setOnClickListener(v -> login(panel.getText().toString(), user.getText().toString(), pass.getText().toString()));
    }

    private void login(String panel, String user, String pass) {
        panel = panel.trim().replaceAll("/+$", "");
        if (!panel.startsWith("https://")) { status.setText("A secure https:// panel address is required"); return; }
        if (user.trim().isEmpty() || pass.isEmpty()) { status.setText("Enter your username and password"); return; }
        setBusy(true, "Signing in securely…");
        final String finalPanel = panel;
        new Thread(() -> {
            try {
                String device = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                JSONObject req = new JSONObject().put("username", user.trim()).put("password", pass).put("device_id", device).put("device_name", android.os.Build.MODEL);
                JSONObject out = request("POST", finalPanel + "/api/login.php", req.toString(), null);
                if (!out.optBoolean("success")) throw new Exception(out.optString("message", "Login failed"));
                panelUrl = finalPanel; token = out.getString("token");
                getPreferences(MODE_PRIVATE).edit().putString("panel", panelUrl).putString("token", token).apply();
                runOnUiThread(this::showServers);
            } catch (Exception e) { runOnUiThread(() -> setBusy(false, safe(e))); }
        }).start();
    }

    private void showServers() {
        base("Choose a secure location");
        LinearLayout toolbar = new LinearLayout(this); toolbar.setGravity(Gravity.CENTER_VERTICAL);
        TextView user = label("AVAILABLE LOCATIONS", 17, CYAN); user.setTypeface(Typeface.DEFAULT_BOLD); toolbar.addView(user, new LinearLayout.LayoutParams(0, -2, 1));
        Button logout = smallAction("LOG OUT"); toolbar.addView(logout); root.addView(toolbar);
        ScrollView scroll = new ScrollView(this); LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); scroll.addView(list); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        logout.setOnClickListener(v -> { getPreferences(MODE_PRIVATE).edit().clear().apply(); token=""; showLogin(); });
        setBusy(true, "Loading VPN locations…");
        new Thread(() -> {
            try {
                JSONObject out = request("GET", panelUrl + "/api/profiles.php", null, token);
                if (!out.optBoolean("success")) throw new Exception(out.optString("message", "Unable to load locations"));
                JSONArray rows = out.getJSONArray("profiles"); servers.clear();
                for (int i=0;i<rows.length();i++) { JSONObject j=rows.getJSONObject(i); if (!"openvpn".equalsIgnoreCase(j.optString("protocol"))) continue; servers.add(new Server(j)); }
                runOnUiThread(() -> { setBusy(false, servers.size()+" locations available"); renderServers(list); });
            } catch (Exception e) { runOnUiThread(() -> { setBusy(false, safe(e)); if (safe(e).toLowerCase(Locale.ROOT).contains("session")) { getPreferences(MODE_PRIVATE).edit().remove("token").apply(); } }); }
        }).start();
    }

    private void renderServers(LinearLayout list) {
        list.removeAllViews();
        if (servers.isEmpty()) { TextView empty=label("No active OpenVPN locations have been added in the panel.",16,Color.LTGRAY); empty.setPadding(dp(16),dp(30),dp(16),dp(30)); list.addView(empty); return; }
        for (Server s : servers) {
            LinearLayout row = card(); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setFocusable(true);
            TextView icon=label("◉",26,CYAN); row.addView(icon,new LinearLayout.LayoutParams(dp(48),-2));
            LinearLayout names=new LinearLayout(this);names.setOrientation(LinearLayout.VERTICAL);TextView name=label(s.name,18,Color.WHITE);name.setTypeface(Typeface.DEFAULT_BOLD);names.addView(name);names.addView(label(s.location()+"  •  OPENVPN",13,Color.rgb(140,170,196)));row.addView(names,new LinearLayout.LayoutParams(0,-2,1));
            Button connect=smallAction("CONNECT");row.addView(connect); View.OnClickListener click=v->connect(s);connect.setOnClickListener(click);row.setOnClickListener(click);list.addView(row,new LinearLayout.LayoutParams(-1,-2));
        }
    }

    private void connect(Server s) {
        try {
            ConfigParser parser = new ConfigParser(); parser.parseConfig(new java.io.StringReader(s.config)); VpnProfile profile = parser.convertProfile();
            profile.mName = "HYDRA SHIELD • " + s.name; profile.mUsername=s.username; profile.mPassword=s.password; profile.mUserEditable=false;
            ProfileManager manager=ProfileManager.getInstance(this); manager.addProfile(profile); ProfileManager.saveProfile(this, profile); manager.saveProfileList(this);
            Intent launch = new Intent(this, LaunchVPN.class); launch.putExtra(LaunchVPN.EXTRA_KEY, profile.getUUIDString()); launch.putExtra(LaunchVPN.EXTRA_HIDELOG, true); startActivity(launch);
            status.setText("Connecting to " + s.name + "…");
        } catch (Exception e) { status.setText("Invalid VPN profile: " + safe(e)); }
    }

    private JSONObject request(String method,String address,String payload,String bearer) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();c.setRequestMethod(method);c.setConnectTimeout(10000);c.setReadTimeout(15000);c.setRequestProperty("Accept","application/json");
        if(bearer!=null)c.setRequestProperty("Authorization","Bearer "+bearer);
        if(payload!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8");try(OutputStream os=c.getOutputStream()){os.write(payload.getBytes(StandardCharsets.UTF_8));}}
        int code=c.getResponseCode();InputStream stream=code>=400?c.getErrorStream():c.getInputStream();StringBuilder text=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(stream,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)text.append(line);}JSONObject out=new JSONObject(text.toString());if(code>=400&&!out.has("message"))out.put("message","Server error "+code);return out;
    }

    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(20),dp(16),dp(20),dp(16));android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable();bg.setColor(PANEL);bg.setCornerRadius(dp(14));bg.setStroke(dp(1),Color.rgb(35,61,84));c.setBackground(bg);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(7),0,dp(7));c.setLayoutParams(lp);return c;}
    private TextView label(String value,int size,int color){TextView v=new TextView(this);v.setText(value);v.setTextSize(size);v.setTextColor(color);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private EditText input(String hint,boolean secret){EditText v=new EditText(this);v.setHint(hint);v.setSingleLine(true);v.setTextColor(Color.WHITE);v.setHintTextColor(Color.rgb(120,145,165));v.setTextSize(17);v.setPadding(dp(15),dp(12),dp(15),dp(12));if(secret)v.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);v.setFocusable(true);return v;}
    private Button action(String value){Button b=new Button(this);b.setText(value);b.setTextColor(Color.WHITE);b.setTextSize(17);b.setTypeface(Typeface.DEFAULT_BOLD);b.setBackgroundColor(BLUE);b.setMinHeight(dp(54));b.setFocusable(true);return b;}
    private Button smallAction(String value){Button b=action(value);b.setTextSize(13);b.setMinWidth(dp(124));return b;}
    private void setBusy(boolean busy,String message){progress.setVisibility(busy?View.VISIBLE:View.GONE);status.setText(message);}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private String safe(Exception e){return e.getMessage()==null?"Unexpected error":e.getMessage();}
    private static final class Server {final String name,country,city,config,username,password;Server(JSONObject j){name=j.optString("name","VPN");country=j.optString("country");city=j.optString("city");config=j.optString("config");username=j.optString("username");password=j.optString("password");}String location(){String x=(city+" "+country).trim();return x.isEmpty()?"Secure server":x;}}
}
