/* HYDRA SHIELD - simple panel-managed multi-provider OpenVPN client. GPLv2. */
package de.blinkt.openvpn.hydra;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import de.blinkt.openvpn.LaunchVPN;
import de.blinkt.openvpn.R;
import de.blinkt.openvpn.VpnProfile;
import de.blinkt.openvpn.activities.DisconnectVPN;
import de.blinkt.openvpn.core.ConfigParser;
import de.blinkt.openvpn.core.ConnectionStatus;
import de.blinkt.openvpn.core.ProfileManager;
import de.blinkt.openvpn.core.VpnStatus;

public final class HydraShieldActivity extends Activity implements VpnStatus.StateListener {
    /* Embedded by the distributor. It is intentionally not shown or editable in the app. */
    private static final String PANEL_URL = "https://p14vpn4pp.ultrawise.uk/vpntest";
    private static final int BG=Color.rgb(4,9,16), CARD=Color.rgb(12,26,42), LINE=Color.rgb(30,65,88);
    private static final int CYAN=Color.rgb(54,225,255), BLUE=Color.rgb(0,125,221), MUTED=Color.rgb(148,174,194);

    private LinearLayout root;
    private TextView status;
    private ProgressBar progress;
    private String token="";
    private String username="";
    private final List<Server> servers=new ArrayList<>();

    @Override public void onCreate(Bundle state){super.onCreate(state);token=getPreferences(MODE_PRIVATE).getString("token","");username=getPreferences(MODE_PRIVATE).getString("username","");if(token.isEmpty())showLogin();else showServers();}
    @Override protected void onResume(){super.onResume();VpnStatus.addStateListener(this);}
    @Override protected void onPause(){VpnStatus.removeStateListener(this);super.onPause();}

    private void base(String subtitle){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(28),dp(18),dp(28),dp(18));root.setBackgroundColor(BG);setContentView(root);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);TextView mark=label("⬡",42,CYAN);mark.setGravity(Gravity.CENTER);head.addView(mark,new LinearLayout.LayoutParams(dp(58),dp(58)));
        LinearLayout names=new LinearLayout(this);names.setOrientation(LinearLayout.VERTICAL);TextView title=label("HYDRA SHIELD",27,Color.WHITE);title.setTypeface(Typeface.DEFAULT_BOLD);title.setLetterSpacing(.08f);names.addView(title);names.addView(label(subtitle,13,MUTED));head.addView(names,new LinearLayout.LayoutParams(0,-2,1));root.addView(head);
        status=label("",14,CYAN);status.setPadding(dp(5),dp(8),dp(5),dp(8));root.addView(status);progress=new ProgressBar(this);progress.setIndeterminate(true);progress.setVisibility(View.GONE);root.addView(progress,new LinearLayout.LayoutParams(-1,dp(4)));
    }

    private void showLogin(){
        base("Private access. One simple login.");
        LinearLayout wrap=new LinearLayout(this);wrap.setGravity(Gravity.CENTER);root.addView(wrap,new LinearLayout.LayoutParams(-1,0,1));LinearLayout box=card();box.setPadding(dp(26),dp(24),dp(26),dp(24));wrap.addView(box,new LinearLayout.LayoutParams(Math.min(dp(520),getResources().getDisplayMetrics().widthPixels-dp(56)),-2));
        TextView h=label("WELCOME BACK",20,CYAN);h.setTypeface(Typeface.DEFAULT_BOLD);box.addView(h);TextView p=label("Sign in with the VPN account supplied by your provider.",14,MUTED);p.setPadding(0,dp(5),0,dp(15));box.addView(p);
        EditText user=input("Username",false);EditText pass=input("Password",true);box.addView(user);box.addView(pass);Button login=action("SIGN IN SECURELY");box.addView(login);login.setOnClickListener(v->login(user.getText().toString(),pass.getText().toString()));
        TextView foot=label("Your panel address and VPN provider details are configured securely.",12,Color.rgb(105,132,153));foot.setGravity(Gravity.CENTER);foot.setPadding(0,dp(16),0,0);box.addView(foot);
    }

    private void login(String user,String pass){
        String loginUser=user.trim();if(loginUser.isEmpty()||pass.isEmpty()){status.setText("Enter your username and password");return;}setBusy(true,"Signing in…");
        new Thread(()->{try{String device=Settings.Secure.getString(getContentResolver(),Settings.Secure.ANDROID_ID);JSONObject body=new JSONObject().put("username",loginUser).put("password",pass).put("device_id",device).put("device_name",android.os.Build.MODEL);JSONObject out=request("POST",PANEL_URL+"/api/login.php",body.toString(),null);if(!out.optBoolean("success"))throw new Exception(out.optString("message","Login failed"));token=out.getString("token");username=out.optString("username",loginUser);getPreferences(MODE_PRIVATE).edit().putString("token",token).putString("username",username).apply();runOnUiThread(this::showServers);}catch(Exception e){runOnUiThread(()->setBusy(false,safe(e)));}}).start();
    }

    private void showServers(){
        base("Choose a provider and secure location");LinearLayout tools=new LinearLayout(this);tools.setGravity(Gravity.CENTER_VERTICAL);LinearLayout who=new LinearLayout(this);who.setOrientation(LinearLayout.VERTICAL);TextView h=label("VPN LOCATIONS",18,CYAN);h.setTypeface(Typeface.DEFAULT_BOLD);who.addView(h);who.addView(label(username.isEmpty()?"Connected account":username,12,MUTED));tools.addView(who,new LinearLayout.LayoutParams(0,-2,1));Button disconnect=small("DISCONNECT");Button logout=small("LOG OUT");tools.addView(disconnect);tools.addView(logout);root.addView(tools);
        disconnect.setOnClickListener(v->startActivity(new Intent(this,DisconnectVPN.class)));logout.setOnClickListener(v->{getPreferences(MODE_PRIVATE).edit().clear().apply();token="";username="";showLogin();});
        ScrollView scroll=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);scroll.addView(list);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setBusy(true,"Loading secure locations…");
        new Thread(()->{try{JSONObject out=request("GET",PANEL_URL+"/api/profiles.php",null,token);if(!out.optBoolean("success"))throw new Exception(out.optString("message","Unable to load locations"));JSONArray rows=out.optJSONArray("profiles");servers.clear();if(rows!=null)for(int i=0;i<rows.length();i++){JSONObject j=rows.getJSONObject(i);if("openvpn".equalsIgnoreCase(j.optString("protocol")))servers.add(new Server(j));}runOnUiThread(()->{setBusy(false,servers.size()+" secure locations available");renderServers(list);});}catch(Exception e){runOnUiThread(()->{setBusy(false,safe(e));if(safe(e).toLowerCase(Locale.ROOT).contains("session")||safe(e).toLowerCase(Locale.ROOT).contains("account")){getPreferences(MODE_PRIVATE).edit().remove("token").apply();}});}}).start();
    }

    private void renderServers(LinearLayout list){
        list.removeAllViews();if(servers.isEmpty()){TextView empty=label("No active OpenVPN locations are available.\nPlease contact your provider.",16,MUTED);empty.setGravity(Gravity.CENTER);empty.setPadding(dp(16),dp(50),dp(16),dp(50));list.addView(empty);return;}
        String last="";for(Server s:servers){if(!s.provider.equalsIgnoreCase(last)){TextView ph=label(s.provider.toUpperCase(Locale.ROOT),12,CYAN);ph.setTypeface(Typeface.DEFAULT_BOLD);ph.setLetterSpacing(.12f);ph.setPadding(dp(4),dp(19),0,dp(4));list.addView(ph);last=s.provider;}
            LinearLayout row=card();row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);TextView dot=label("●",22,CYAN);row.addView(dot,new LinearLayout.LayoutParams(dp(42),-2));LinearLayout n=new LinearLayout(this);n.setOrientation(LinearLayout.VERTICAL);TextView name=label(s.name,17,Color.WHITE);name.setTypeface(Typeface.DEFAULT_BOLD);n.addView(name);n.addView(label(s.location()+"  •  "+s.transport.toUpperCase(Locale.ROOT),12,MUTED));row.addView(n,new LinearLayout.LayoutParams(0,-2,1));Button go=small("CONNECT");row.addView(go);View.OnClickListener click=v->connect(s);go.setOnClickListener(click);row.setOnClickListener(click);list.addView(row);}
    }

    private void connect(Server s){setBusy(true,"Preparing "+s.name+"…");new Thread(()->{try{String config=s.config.trim();if(config.startsWith("https://")||config.startsWith("http://"))config=download(config);if(config.isEmpty())throw new Exception("The panel returned an empty OpenVPN configuration");if(!config.matches("(?s).*\\n?remote\\s+.+"))throw new Exception("This profile has no remote VPN server");ConfigParser parser=new ConfigParser();parser.parseConfig(new java.io.StringReader(config));VpnProfile profile=parser.convertProfile();profile.mName="HYDRA SHIELD • "+s.provider+" • "+s.name;profile.mUsername=s.username;profile.mPassword=s.password;profile.mUserEditable=false;int error=profile.checkProfile(this);if(error!=R.string.no_error_found)throw new Exception(getString(error));ProfileManager manager=ProfileManager.getInstance(this);manager.addProfile(profile);ProfileManager.saveProfile(this,profile);manager.saveProfileList(this);Intent launch=new Intent(this,LaunchVPN.class);launch.setAction(Intent.ACTION_MAIN);launch.putExtra(LaunchVPN.EXTRA_KEY,profile.getUUIDString());launch.putExtra(LaunchVPN.EXTRA_HIDELOG,false);runOnUiThread(()->{setBusy(false,"Starting "+s.name+"…");startActivity(launch);});}catch(Exception e){runOnUiThread(()->setBusy(false,"Could not connect: "+safe(e)));}}).start();}

    private String download(String address)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(22000);c.setInstanceFollowRedirects(true);c.setRequestProperty("Accept","application/x-openvpn-profile,text/plain,*/*");int code=c.getResponseCode();InputStream in=code>=400?c.getErrorStream():c.getInputStream();if(in==null)throw new Exception("Profile download failed (HTTP "+code+")");StringBuilder out=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)out.append(line).append('\n');}if(code>=400)throw new Exception("Profile download failed (HTTP "+code+")");return out.toString();}
    private JSONObject request(String method,String address,String payload,String bearer)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();c.setRequestMethod(method);c.setConnectTimeout(10000);c.setReadTimeout(18000);c.setRequestProperty("Accept","application/json");if(bearer!=null)c.setRequestProperty("Authorization","Bearer "+bearer);if(payload!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8");try(OutputStream os=c.getOutputStream()){os.write(payload.getBytes(StandardCharsets.UTF_8));}}int code=c.getResponseCode();InputStream in=code>=400?c.getErrorStream():c.getInputStream();if(in==null)throw new Exception("Panel error "+code);StringBuilder raw=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)raw.append(line);}JSONObject out=new JSONObject(raw.toString());if(code>=400&&!out.has("message"))out.put("message","Panel error "+code);return out;}

    @Override public void updateState(String state,String log,int res,ConnectionStatus level,Intent intent){runOnUiThread(()->{if(status!=null){if("CONNECTED".equals(state))status.setText("● VPN CONNECTED");else if("NOPROCESS".equals(state)||"DISCONNECTED".equals(state))status.setText("VPN disconnected");else if(state!=null&&!state.isEmpty())status.setText(state.replace('_',' '));}});}
    @Override public void setConnectedVPN(String uuid){}
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(18),dp(15),dp(18),dp(15));android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(14,31,49),CARD});bg.setCornerRadius(dp(14));bg.setStroke(dp(1),LINE);c.setBackground(bg);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(6),0,dp(6));c.setLayoutParams(lp);return c;}
    private TextView label(String s,int z,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(color);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private EditText input(String hint,boolean secret){EditText v=new EditText(this);v.setHint(hint);v.setSingleLine();v.setTextColor(Color.WHITE);v.setHintTextColor(Color.rgb(112,140,160));v.setTextSize(17);v.setPadding(dp(15),dp(12),dp(15),dp(12));android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable();bg.setColor(Color.rgb(7,17,29));bg.setCornerRadius(dp(9));bg.setStroke(dp(1),LINE);v.setBackground(bg);if(secret)v.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(54));lp.setMargins(0,dp(7),0,dp(7));v.setLayoutParams(lp);return v;}
    private Button action(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(15);b.setTypeface(Typeface.DEFAULT_BOLD);android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,new int[]{BLUE,Color.rgb(0,177,210)});bg.setCornerRadius(dp(9));b.setBackground(bg);b.setMinHeight(dp(52));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.setMargins(0,dp(10),0,0);b.setLayoutParams(lp);return b;}
    private Button small(String s){Button b=action(s);b.setTextSize(11);b.setMinWidth(dp(112));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(44));lp.setMargins(dp(7),0,0,0);b.setLayoutParams(lp);return b;}
    private void setBusy(boolean busy,String message){progress.setVisibility(busy?View.VISIBLE:View.GONE);status.setText(message);}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private String safe(Exception e){return e.getMessage()==null?"Unexpected error":e.getMessage();}
    private static String first(JSONObject j,String...keys){for(String k:keys){String v=j.optString(k,"").trim();if(!v.isEmpty())return v;}return"";}
    private static final class Server{final String name,country,city,provider,transport,config,username,password;Server(JSONObject j){String n=first(j,"name","profile_name","location_name");name=n.isEmpty()?"VPN Location":n;country=first(j,"country","country_name");city=first(j,"city","location","state","region");String p=first(j,"provider","vpn_provider");provider=p.isEmpty()?"Custom":p;String t=first(j,"transport","proto","vpn_protocol");transport=t.isEmpty()?"OpenVPN":t;config=first(j,"config","ovpn","ovpn_config","config_url","ovpn_url","profile_path");username=first(j,"username","vpn_username","provider_username","user");password=first(j,"password","vpn_password","provider_password","pass");}String location(){String x=(city+" "+country).trim();return x.isEmpty()?provider:x;}}
}
