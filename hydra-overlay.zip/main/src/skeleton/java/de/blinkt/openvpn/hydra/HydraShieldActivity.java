/* HYDRA SHIELD - simple panel-managed multi-provider OpenVPN client. GPLv2. */
package de.blinkt.openvpn.hydra;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.HorizontalScrollView;
import android.widget.Switch;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import de.blinkt.openvpn.LaunchVPN;
import de.blinkt.openvpn.R;
import de.blinkt.openvpn.VpnProfile;
import de.blinkt.openvpn.activities.DisconnectVPN;
import de.blinkt.openvpn.core.ConfigParser;
import de.blinkt.openvpn.core.ConnectionStatus;
import de.blinkt.openvpn.core.ProfileManager;
import de.blinkt.openvpn.core.VpnStatus;

public final class HydraShieldActivity extends Activity implements VpnStatus.StateListener {
    /* Embedded by the distributor. It is intentionally not shown or editable in the app. */
    private static final String PANEL_URL = "https://p14vpn4pp.ultrawise.uk/vpntest";
    private static final int BG=Color.rgb(4,9,16), CARD=Color.rgb(12,26,42), LINE=Color.rgb(30,65,88);
    private static final int CYAN=Color.rgb(54,225,255), BLUE=Color.rgb(0,125,221), MUTED=Color.rgb(148,174,194);

    private LinearLayout root;
    private TextView status;
    private ProgressBar progress;
    private Button loginButton;
    private Button disconnectButton;
    private Spinner serviceSpinner;
    private final List<String> serviceIds=new ArrayList<>();
    private String token="";
    private String username="";
    private final List<Server> servers=new ArrayList<>();
    private final Map<String,Button> connectButtons=new LinkedHashMap<>();
    private final Map<String,Integer> latencies=new ConcurrentHashMap<>();
    private String selectedLocation="";
    private String selectedProvider="";
    private TextView timerView,ipView,activeLocationView;
    private final Handler clock=new Handler(Looper.getMainLooper());
    private final Handler connectionWatchdog=new Handler(Looper.getMainLooper());
    private final Runnable connectionSlow=()->{if(status!=null)status.setText("Connection is taking longer than expected. Try another location if it does not connect.");};
    private long connectedAt=0;
    private boolean vpnConnected=false;
    private final Runnable tick=new Runnable(){public void run(){if(timerView!=null&&connectedAt>0){long s=(System.currentTimeMillis()-connectedAt)/1000;timerView.setText(String.format(Locale.ROOT,"CONNECTED  %02d:%02d:%02d",s/3600,(s/60)%60,s%60));clock.postDelayed(this,1000);}}};

    @Override public void onCreate(Bundle state){super.onCreate(state);token=getPreferences(MODE_PRIVATE).getString("token","");username=getPreferences(MODE_PRIVATE).getString("username","");if(token.isEmpty())showLogin();else showServers();}
    @Override protected void onResume(){super.onResume();VpnStatus.addStateListener(this);}
    @Override protected void onPause(){VpnStatus.removeStateListener(this);super.onPause();}

    private void base(String subtitle){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(22),dp(16),dp(22),dp(16));root.setBackgroundColor(BG);setContentView(root);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);TextView mark=label("⬡",42,CYAN);mark.setGravity(Gravity.CENTER);head.addView(mark,new LinearLayout.LayoutParams(dp(58),dp(58)));
        LinearLayout names=new LinearLayout(this);names.setOrientation(LinearLayout.VERTICAL);TextView title=label("VELORA VPN",27,Color.WHITE);title.setTypeface(Typeface.DEFAULT_BOLD);title.setLetterSpacing(.08f);names.addView(title);names.addView(label(subtitle,13,MUTED));head.addView(names,new LinearLayout.LayoutParams(0,-2,1));root.addView(head);
        status=label("",14,CYAN);status.setPadding(dp(12),dp(9),dp(12),dp(9));status.setBackground(rounded(Color.rgb(7,19,31),dp(10),LINE));root.addView(status);progress=new ProgressBar(this);progress.setIndeterminate(true);progress.setVisibility(View.GONE);root.addView(progress,new LinearLayout.LayoutParams(-1,dp(4)));
    }

    private void showLogin(){
        base("Private access. One simple login.");
        LinearLayout wrap=new LinearLayout(this);wrap.setGravity(Gravity.CENTER);root.addView(wrap,new LinearLayout.LayoutParams(-1,0,1));LinearLayout box=card();box.setPadding(dp(26),dp(24),dp(26),dp(24));wrap.addView(box,new LinearLayout.LayoutParams(Math.min(dp(520),getResources().getDisplayMetrics().widthPixels-dp(56)),-2));
        TextView h=label("WELCOME BACK",20,CYAN);h.setTypeface(Typeface.DEFAULT_BOLD);box.addView(h);TextView p=label("Sign in with the VPN account supplied by your provider.",14,MUTED);p.setPadding(0,dp(5),0,dp(15));box.addView(p);
        TextView serviceLabel=label("VPN SERVER",12,MUTED);serviceLabel.setPadding(0,0,0,dp(5));box.addView(serviceLabel);serviceSpinner=new Spinner(this);serviceSpinner.setPadding(dp(12),0,dp(12),0);serviceSpinner.setBackground(rounded(Color.rgb(7,17,29),dp(9),LINE));box.addView(serviceSpinner,new LinearLayout.LayoutParams(-1,dp(54)));EditText user=input("Username",false);EditText pass=input("Password",true);user.setText(getPreferences(MODE_PRIVATE).getString("saved_username",""));pass.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_DONE);box.addView(user);box.addView(pass);loginButton=action("SIGN IN SECURELY");loginButton.setEnabled(false);loginButton.setAlpha(.55f);box.addView(loginButton);View.OnClickListener submit=v->{int pos=serviceSpinner==null?-1:serviceSpinner.getSelectedItemPosition();String serviceId=pos>=0&&pos<serviceIds.size()?serviceIds.get(pos):"";login(user.getText().toString(),pass.getText().toString(),serviceId);};loginButton.setOnClickListener(submit);pass.setOnEditorActionListener((v,id,event)->{if(id==android.view.inputmethod.EditorInfo.IME_ACTION_DONE){submit.onClick(v);return true;}return false;});loadServices();
        TextView foot=label("Your panel address and VPN provider details are configured securely.",12,Color.rgb(105,132,153));foot.setGravity(Gravity.CENTER);foot.setPadding(0,dp(16),0,0);box.addView(foot);
    }

    private void loadServices(){status.setText("Loading available servers…");new Thread(()->{try{JSONObject out=request("GET",PANEL_URL+"/api/services.php",null,null);if(!out.optBoolean("success"))throw new Exception(out.optString("message","Unable to load servers"));JSONArray rows=out.optJSONArray("services");List<String> names=new ArrayList<>();serviceIds.clear();if(rows!=null)for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i);String id=row.optString("id","");String name=row.optString("name","").trim();if(!id.isEmpty()&&!name.isEmpty()){serviceIds.add(id);names.add(name);}}runOnUiThread(()->{if(names.isEmpty()){status.setText("No VPN servers are enabled. Contact your provider.");return;}ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,names){@Override public View getView(int p,View v,android.view.ViewGroup parent){TextView t=(TextView)super.getView(p,v,parent);t.setTextColor(Color.WHITE);t.setTextSize(16);return t;}@Override public View getDropDownView(int p,View v,android.view.ViewGroup parent){TextView t=(TextView)super.getDropDownView(p,v,parent);t.setTextColor(Color.WHITE);t.setBackgroundColor(CARD);t.setPadding(dp(14),dp(13),dp(14),dp(13));return t;}};adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);serviceSpinner.setAdapter(adapter);String saved=getPreferences(MODE_PRIVATE).getString("selected_dns_service","");int selected=serviceIds.indexOf(saved);if(selected>=0)serviceSpinner.setSelection(selected);loginButton.setEnabled(true);loginButton.setAlpha(1f);status.setText("Select your server and sign in");});}catch(Exception e){runOnUiThread(()->{status.setText("Could not load servers: "+safe(e));loginButton.setEnabled(false);loginButton.setAlpha(.55f);});}}).start();}

    private void login(String user,String pass,String serviceId){
        String loginUser=user.trim();if(loginButton!=null&&!loginButton.isEnabled())return;if(serviceId.isEmpty()){status.setText("Select a VPN server");return;}if(loginUser.isEmpty()||pass.isEmpty()){status.setText("Enter your username and password");return;}getPreferences(MODE_PRIVATE).edit().putString("saved_username",loginUser).putString("selected_dns_service",serviceId).apply();setBusy(true,"Checking your account…");
        new Thread(()->{try{String device=Settings.Secure.getString(getContentResolver(),Settings.Secure.ANDROID_ID);JSONObject body=new JSONObject().put("username",loginUser).put("password",pass).put("dns_service_id",serviceId).put("device_id",device).put("device_name",android.os.Build.MODEL);JSONObject out=request("POST",PANEL_URL+"/api/login.php",body.toString(),null);if(!out.optBoolean("success"))throw new Exception(out.optString("message","Login failed"));token=out.getString("token");username=out.optString("username",loginUser);getPreferences(MODE_PRIVATE).edit().putString("token",token).putString("username",username).putString("service_name",out.optString("service_name","")).apply();runOnUiThread(this::showServers);}catch(Exception e){runOnUiThread(()->setBusy(false,safe(e)));}}).start();
    }

    private void showServers(){
        base("Private, fast and beautifully simple");LinearLayout tools=new LinearLayout(this);tools.setGravity(Gravity.CENTER_VERTICAL);LinearLayout who=new LinearLayout(this);who.setOrientation(LinearLayout.VERTICAL);TextView h=label("SECURE LOCATIONS",18,CYAN);h.setTypeface(Typeface.DEFAULT_BOLD);who.addView(h);String serviceName=getPreferences(MODE_PRIVATE).getString("service_name","");who.addView(label(serviceName.isEmpty()?(username.isEmpty()?"Connected account":username):serviceName+"  •  "+username,12,MUTED));tools.addView(who,new LinearLayout.LayoutParams(0,-2,1));Button disconnect=small("DISCONNECT");Button logout=small("LOG OUT");tools.addView(disconnect);tools.addView(logout);root.addView(tools);
        LinearLayout info=card();LinearLayout infoTop=new LinearLayout(this);infoTop.setOrientation(LinearLayout.HORIZONTAL);timerView=label("NOT CONNECTED",13,Color.WHITE);timerView.setTypeface(Typeface.DEFAULT_BOLD);ipView=label("IP: checking…",13,MUTED);ipView.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);infoTop.addView(timerView,new LinearLayout.LayoutParams(0,dp(34),1));infoTop.addView(ipView,new LinearLayout.LayoutParams(0,dp(34),1));info.addView(infoTop);activeLocationView=label("No active VPN location",15,MUTED);activeLocationView.setTypeface(Typeface.DEFAULT_BOLD);activeLocationView.setPadding(0,dp(2),0,dp(4));info.addView(activeLocationView);root.addView(info);
        Switch reconnect=new Switch(this);reconnect.setText("Automatic reconnect");reconnect.setTextColor(Color.WHITE);reconnect.setChecked(getPreferences(MODE_PRIVATE).getBoolean("auto_reconnect",false));reconnect.setPadding(dp(5),dp(2),dp(5),dp(2));reconnect.setOnCheckedChangeListener((b,on)->{getPreferences(MODE_PRIVATE).edit().putBoolean("auto_reconnect",on).apply();android.preference.PreferenceManager.getDefaultSharedPreferences(this).edit().putBoolean("netchangereconnect",on).apply();});root.addView(reconnect);
        refreshPublicIp();EditText search=input("Search country or location",false);search.setTextSize(15);root.addView(search);
        disconnectButton=disconnect;disconnectButton.setVisibility(View.GONE);disconnect.setOnClickListener(v->startActivity(new Intent(this,DisconnectVPN.class)));logout.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle("Log out?").setMessage("You will need your VPN username and password to sign in again.").setNegativeButton("CANCEL",null).setPositiveButton("LOG OUT",(d,w)->{getPreferences(MODE_PRIVATE).edit().remove("token").remove("username").remove("service_name").apply();token="";username="";showLogin();}).show());
        ScrollView scroll=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);scroll.addView(list);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setBusy(true,"Loading secure locations…");
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){renderServers(list,s.toString());}public void afterTextChanged(Editable e){}});
        new Thread(()->{try{JSONObject out=request("GET",PANEL_URL+"/api/profiles.php",null,token);if(!out.optBoolean("success"))throw new Exception(out.optString("message","Unable to load locations"));JSONArray rows=out.optJSONArray("profiles");servers.clear();latencies.clear();if(rows!=null)for(int i=0;i<rows.length();i++){JSONObject j=rows.getJSONObject(i);if("openvpn".equalsIgnoreCase(j.optString("protocol")))servers.add(new Server(j));}runOnUiThread(()->{setBusy(false,servers.size()+" secure locations available • checking speeds…");renderServers(list,search.getText().toString());});probeLatencies(list,search);}catch(Exception e){runOnUiThread(()->{setBusy(false,safe(e));if(safe(e).toLowerCase(Locale.ROOT).contains("session")||safe(e).toLowerCase(Locale.ROOT).contains("account")){getPreferences(MODE_PRIVATE).edit().remove("token").apply();}});}}).start();
    }

    private void renderServers(LinearLayout list){renderServers(list,"");}
    private void renderServers(LinearLayout list,String query){
        list.removeAllViews();connectButtons.clear();if(servers.isEmpty()){TextView empty=label("No active OpenVPN locations are available.\nPlease contact your provider.",16,MUTED);empty.setGravity(Gravity.CENTER);empty.setPadding(dp(16),dp(50),dp(16),dp(50));list.addView(empty);return;}
        String q=query==null?"":query.trim().toLowerCase(Locale.ROOT);Set<String> favs=getPreferences(MODE_PRIVATE).getStringSet("favorite_servers",Collections.emptySet());TreeMap<String,Boolean> providerNames=new TreeMap<>(String.CASE_INSENSITIVE_ORDER);for(Server s:servers)providerNames.put(s.provider,true);HorizontalScrollView providerScroll=new HorizontalScrollView(this);providerScroll.setHorizontalScrollBarEnabled(false);LinearLayout providerBar=new LinearLayout(this);providerBar.setOrientation(LinearLayout.HORIZONTAL);Button favButton=small("★ FAVOURITES");favButton.setOnClickListener(v->{selectedProvider="__favorites__";renderServers(list,query);});styleTab(favButton,"__favorites__".equals(selectedProvider));providerBar.addView(favButton);for(String provider:providerNames.keySet()){Button tab=small(provider.toUpperCase(Locale.ROOT));tab.setOnClickListener(v->{selectedProvider=provider;renderServers(list,query);});styleTab(tab,provider.equalsIgnoreCase(selectedProvider));providerBar.addView(tab);}providerScroll.addView(providerBar);list.addView(providerScroll,new LinearLayout.LayoutParams(-1,dp(54)));
        if(selectedProvider.isEmpty()&&q.isEmpty()){TextView choose=label("Choose a VPN company above to view its locations.",15,MUTED);choose.setGravity(Gravity.CENTER);choose.setPadding(dp(12),dp(32),dp(12),dp(32));list.addView(choose);return;}
        Map<String,List<Server>> groups=new TreeMap<>(String.CASE_INSENSITIVE_ORDER);for(Server s:servers){if("__favorites__".equals(selectedProvider)&&!favs.contains(s.key()))continue;if(!selectedProvider.isEmpty()&&!"__favorites__".equals(selectedProvider)&&!s.provider.equalsIgnoreCase(selectedProvider))continue;if(!q.isEmpty()&&!(s.provider+" "+s.name+" "+s.city+" "+s.country).toLowerCase(Locale.ROOT).contains(q))continue;groups.computeIfAbsent(s.provider,k->new ArrayList<>()).add(s);}for(List<Server> values:groups.values())values.sort(Comparator.comparing((Server s)->!favs.contains(s.key())).thenComparingInt(s->latencies.getOrDefault(s.key(),Integer.MAX_VALUE)).thenComparing(Server::location,String.CASE_INSENSITIVE_ORDER).thenComparing(s->s.name,String.CASE_INSENSITIVE_ORDER));
        if(groups.isEmpty()){TextView empty=label("__favorites__".equals(selectedProvider)?"No favourite locations yet. Tap ☆ beside a location to save it.":"No locations match your selection.",15,MUTED);empty.setGravity(Gravity.CENTER);empty.setPadding(dp(12),dp(35),dp(12),dp(35));list.addView(empty);return;}
        for(Map.Entry<String,List<Server>> group:groups.entrySet()){LinearLayout section=card();section.setPadding(dp(14),dp(10),dp(14),dp(12));LinearLayout heading=new LinearLayout(this);heading.setGravity(Gravity.CENTER_VERTICAL);TextView ph=label(group.getKey().toUpperCase(Locale.ROOT),14,CYAN);ph.setTypeface(Typeface.DEFAULT_BOLD);ph.setLetterSpacing(.1f);heading.addView(ph,new LinearLayout.LayoutParams(0,dp(42),1));TextView count=label(group.getValue().size()+" LOCATIONS",11,MUTED);count.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);heading.addView(count);section.addView(heading);
            for(Server s:group.getValue()){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(6),dp(8),dp(4),dp(8));TextView star=label(favs.contains(s.key())?"★":"☆",25,favs.contains(s.key())?Color.rgb(255,204,64):MUTED);star.setGravity(Gravity.CENTER);star.setOnClickListener(v->{Set<String> updated=new HashSet<>(getPreferences(MODE_PRIVATE).getStringSet("favorite_servers",Collections.emptySet()));if(updated.contains(s.key()))updated.remove(s.key());else updated.add(s.key());getPreferences(MODE_PRIVATE).edit().putStringSet("favorite_servers",updated).apply();renderServers(list,query);});row.addView(star,new LinearLayout.LayoutParams(dp(42),dp(46)));TextView flag=label(s.flag(),29,Color.WHITE);flag.setGravity(Gravity.CENTER);row.addView(flag,new LinearLayout.LayoutParams(dp(46),dp(46)));LinearLayout n=new LinearLayout(this);n.setOrientation(LinearLayout.VERTICAL);TextView name=label(s.name,16,Color.WHITE);name.setTypeface(Typeface.DEFAULT_BOLD);n.addView(name);Integer ms=latencies.get(s.key());String speed=ms==null?"CHECKING…":ms<0?"PING UNAVAILABLE":ms+" ms";int speedColor=ms!=null&&ms>=0&&ms<100?Color.rgb(66,214,129):MUTED;n.addView(label(s.location()+"  •  "+s.transport.toUpperCase(Locale.ROOT)+"  •  "+speed,12,speedColor));row.addView(n,new LinearLayout.LayoutParams(0,-2,1));Button go=small("CONNECT");styleConnect(go,false);connectButtons.put(s.key(),go);row.addView(go);View.OnClickListener click=v->connect(s);go.setOnClickListener(click);section.addView(row);}
            list.addView(section);}if(vpnConnected){String active=getPreferences(MODE_PRIVATE).getString("selected_server","");for(Map.Entry<String,Button> e:connectButtons.entrySet())styleConnect(e.getValue(),e.getKey().equals(active));}
    }

    private void connect(Server s){selectedLocation=s.flag()+" "+s.name;getPreferences(MODE_PRIVATE).edit().putString("last_location",selectedLocation).putString("selected_server",s.key()).apply();connectionWatchdog.removeCallbacks(connectionSlow);connectionWatchdog.postDelayed(connectionSlow,45000);setBusy(true,"Preparing "+selectedLocation+"…");new Thread(()->{try{String config=s.config.trim();if(config.startsWith("https://")||config.startsWith("http://"))config=download(config);if(config.isEmpty())throw new Exception("The panel returned an empty OpenVPN configuration");if(!config.matches("(?s).*\\n?remote\\s+.+"))throw new Exception("This profile has no remote VPN server");ConfigParser parser=new ConfigParser();parser.parseConfig(new java.io.StringReader(config));VpnProfile profile=parser.convertProfile();profile.mName="VELORA VPN • "+s.provider+" • "+s.name;profile.mUsername=s.username;profile.mPassword=s.password;profile.mUserEditable=false;profile.mPersistTun=getPreferences(MODE_PRIVATE).getBoolean("auto_reconnect",false);int error=profile.checkProfile(this);if(error!=R.string.no_error_found)throw new Exception(getString(error));ProfileManager manager=ProfileManager.getInstance(this);manager.addProfile(profile);ProfileManager.saveProfile(this,profile);manager.saveProfileList(this);Intent launch=new Intent(this,LaunchVPN.class);launch.setAction(Intent.ACTION_MAIN);launch.putExtra(LaunchVPN.EXTRA_KEY,profile.getUUIDString());launch.putExtra(LaunchVPN.EXTRA_HIDELOG,true);runOnUiThread(()->{setBusy(false,"Connecting to "+selectedLocation+"…");startActivity(launch);});}catch(Exception e){connectionWatchdog.removeCallbacks(connectionSlow);runOnUiThread(()->setBusy(false,"Could not connect: "+friendlyError(e)));}}).start();}

    private void refreshPublicIp(){new Thread(()->{try{HttpURLConnection c=(HttpURLConnection)new URL("https://api.ipify.org").openConnection();c.setConnectTimeout(6000);c.setReadTimeout(6000);StringBuilder v=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),StandardCharsets.UTF_8))){String x;while((x=r.readLine())!=null)v.append(x);}runOnUiThread(()->{if(ipView!=null)ipView.setText("IP: "+v);});}catch(Exception ignored){runOnUiThread(()->{if(ipView!=null)ipView.setText("IP unavailable");});}}).start();}

    private void probeLatencies(LinearLayout list,EditText search){ExecutorService pool=Executors.newFixedThreadPool(4);CountDownLatch done=new CountDownLatch(servers.size());for(Server s:servers)pool.execute(()->{int result=-1;if(!s.host.isEmpty()){long start=System.nanoTime();try(Socket socket=new Socket()){socket.connect(new InetSocketAddress(s.host,s.port),1200);result=(int)((System.nanoTime()-start)/1000000L);}catch(Exception ignored){}}latencies.put(s.key(),result);done.countDown();});pool.shutdown();try{done.await(8,TimeUnit.SECONDS);}catch(InterruptedException ignored){Thread.currentThread().interrupt();}runOnUiThread(()->{if(root!=null&&list.getParent()!=null){status.setText(servers.size()+" secure locations • fastest shown first");renderServers(list,search.getText().toString());}});}

    private String download(String address)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(22000);c.setInstanceFollowRedirects(true);c.setRequestProperty("Accept","application/x-openvpn-profile,text/plain,*/*");int code=c.getResponseCode();InputStream in=code>=400?c.getErrorStream():c.getInputStream();if(in==null)throw new Exception("Profile download failed (HTTP "+code+")");StringBuilder out=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)out.append(line).append('\n');}if(code>=400)throw new Exception("Profile download failed (HTTP "+code+")");return out.toString();}
    private JSONObject request(String method,String address,String payload,String bearer)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();c.setRequestMethod(method);c.setConnectTimeout(10000);c.setReadTimeout(18000);c.setRequestProperty("Accept","application/json");if(bearer!=null)c.setRequestProperty("Authorization","Bearer "+bearer);if(payload!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8");try(OutputStream os=c.getOutputStream()){os.write(payload.getBytes(StandardCharsets.UTF_8));}}int code=c.getResponseCode();InputStream in=code>=400?c.getErrorStream():c.getInputStream();if(in==null)throw new Exception("Panel error "+code);StringBuilder raw=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)raw.append(line);}JSONObject out=new JSONObject(raw.toString());if(code>=400&&!out.has("message"))out.put("message","Panel error "+code);return out;}

    @Override public void updateState(String state,String log,int res,ConnectionStatus level,Intent intent){runOnUiThread(()->{if(status!=null){if(level==ConnectionStatus.LEVEL_CONNECTED){vpnConnected=true;connectionWatchdog.removeCallbacks(connectionSlow);status.setText("● SECURED"+(selectedLocation.isEmpty()?"":"  •  "+selectedLocation));if(activeLocationView!=null){activeLocationView.setText(selectedLocation.isEmpty()?"VPN connection secured":selectedLocation);activeLocationView.setTextColor(Color.rgb(66,214,129));}if(disconnectButton!=null)disconnectButton.setVisibility(View.VISIBLE);String active=getPreferences(MODE_PRIVATE).getString("selected_server","");for(Map.Entry<String,Button> e:connectButtons.entrySet())styleConnect(e.getValue(),e.getKey().equals(active));connectedAt=System.currentTimeMillis();clock.removeCallbacks(tick);clock.post(tick);refreshPublicIp();}else if(level==ConnectionStatus.LEVEL_NOTCONNECTED||level==ConnectionStatus.LEVEL_AUTH_FAILED){vpnConnected=false;connectionWatchdog.removeCallbacks(connectionSlow);if(disconnectButton!=null)disconnectButton.setVisibility(View.GONE);status.setText("○ VPN disconnected");if(activeLocationView!=null){activeLocationView.setText("No active VPN location");activeLocationView.setTextColor(MUTED);}for(Button b:connectButtons.values())styleConnect(b,false);connectedAt=0;clock.removeCallbacks(tick);if(timerView!=null)timerView.setText("NOT CONNECTED");refreshPublicIp();}else if(state!=null&&!state.isEmpty())status.setText(state.replace('_',' '));}});}
    @Override public void setConnectedVPN(String uuid){}
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(18),dp(15),dp(18),dp(15));android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(14,31,49),CARD});bg.setCornerRadius(dp(14));bg.setStroke(dp(1),LINE);c.setBackground(bg);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(6),0,dp(6));c.setLayoutParams(lp);return c;}
    private android.graphics.drawable.GradientDrawable rounded(int color,float radius,int stroke){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(radius);d.setStroke(dp(1),stroke);return d;}
    private TextView label(String s,int z,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(color);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private EditText input(String hint,boolean secret){EditText v=new EditText(this);v.setHint(hint);v.setSingleLine();v.setTextColor(Color.WHITE);v.setHintTextColor(Color.rgb(112,140,160));v.setTextSize(17);v.setPadding(dp(15),dp(12),dp(15),dp(12));android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable();bg.setColor(Color.rgb(7,17,29));bg.setCornerRadius(dp(9));bg.setStroke(dp(1),LINE);v.setBackground(bg);if(secret)v.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(54));lp.setMargins(0,dp(7),0,dp(7));v.setLayoutParams(lp);return v;}
    private Button action(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(15);b.setTypeface(Typeface.DEFAULT_BOLD);android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,new int[]{BLUE,Color.rgb(0,177,210)});bg.setCornerRadius(dp(9));b.setBackground(bg);b.setMinHeight(dp(52));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.setMargins(0,dp(10),0,0);b.setLayoutParams(lp);return b;}
    private Button small(String s){Button b=action(s);b.setTextSize(11);b.setMinWidth(dp(112));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(44));lp.setMargins(dp(7),0,0,0);b.setLayoutParams(lp);return b;}
    private void styleConnect(Button b,boolean connected){b.setText(connected?"CONNECTED":"CONNECT");android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,connected?new int[]{Color.rgb(8,145,82),Color.rgb(20,190,105)}:new int[]{BLUE,Color.rgb(0,177,210)});bg.setCornerRadius(dp(9));b.setBackground(bg);}
    private void styleTab(Button b,boolean selected){android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable();bg.setColor(selected?Color.rgb(32,102,154):Color.rgb(12,30,47));bg.setCornerRadius(dp(9));bg.setStroke(dp(1),selected?CYAN:LINE);b.setBackground(bg);}
    private void setBusy(boolean busy,String message){progress.setVisibility(busy?View.VISIBLE:View.GONE);status.setText(message);if(loginButton!=null){loginButton.setEnabled(!busy);loginButton.setAlpha(busy?.55f:1f);}}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private String safe(Exception e){return e.getMessage()==null?"Unexpected error":e.getMessage();}
    private String friendlyError(Exception e){String m=safe(e);String l=m.toLowerCase(Locale.ROOT);if(l.contains("timed out")||l.contains("timeout"))return "Connection timed out. Check your internet or try another location.";if(l.contains("unable to resolve")||l.contains("unknown host"))return "VPN server could not be found. Try another location.";if(l.contains("authentication")||l.contains("auth_failed"))return "VPN provider username or password was rejected.";return m;}
    private static String first(JSONObject j,String...keys){for(String k:keys){String v=j.optString(k,"").trim();if(!v.isEmpty())return v;}return"";}
    private static String countryCode(String value){String s=value.toLowerCase(Locale.ROOT);String[][] map={{"united kingdom","GB"},{"great britain","GB"},{" uk","GB"},{"london","GB"},{"manchester","GB"},{"united states","US"},{" usa","US"},{"new york","US"},{"los angeles","US"},{"chicago","US"},{"miami","US"},{"canada","CA"},{"toronto","CA"},{"montreal","CA"},{"australia","AU"},{"sydney","AU"},{"melbourne","AU"},{"germany","DE"},{"frankfurt","DE"},{"netherlands","NL"},{"amsterdam","NL"},{"france","FR"},{"paris","FR"},{"spain","ES"},{"madrid","ES"},{"italy","IT"},{"rome","IT"},{"switzerland","CH"},{"sweden","SE"},{"norway","NO"},{"denmark","DK"},{"finland","FI"},{"ireland","IE"},{"poland","PL"},{"austria","AT"},{"belgium","BE"},{"portugal","PT"},{"japan","JP"},{"singapore","SG"},{"india","IN"},{"brazil","BR"},{"mexico","MX"},{"south africa","ZA"},{"new zealand","NZ"},{"romania","RO"},{"czech","CZ"},{"turkey","TR"},{"hong kong","HK"}};for(String[] x:map)if(s.contains(x[0]))return x[1];String clean=value.trim().toUpperCase(Locale.ROOT);return clean.matches("[A-Z]{2}")?clean:"";}
    private static String flagEmoji(String code){if(code.length()!=2)return "🌐";int a=Character.codePointAt(code,0)-'A'+0x1F1E6,b=Character.codePointAt(code,1)-'A'+0x1F1E6;return new String(Character.toChars(a))+new String(Character.toChars(b));}
    private static final class Server{final String name,country,city,provider,transport,config,username,password,host;final int port;Server(JSONObject j){String n=first(j,"name","profile_name","location_name");name=n.isEmpty()?"VPN Location":n;country=first(j,"country_code","country","country_name");city=first(j,"city","location","state","region");String p=first(j,"provider","vpn_provider");provider=p.isEmpty()?"Custom":p;String t=first(j,"transport","proto","vpn_protocol");transport=t.isEmpty()?"OpenVPN":t;config=first(j,"config","ovpn","ovpn_config","config_url","ovpn_url","profile_path");username=first(j,"username","vpn_username","provider_username","user");password=first(j,"password","vpn_password","provider_password","pass");String endpoint=first(j,"hostname","host","server","remote");int endpointPort=j.optInt("port",0);if(endpoint.isEmpty()&&!config.startsWith("http")){for(String line:config.split("\\r?\\n")){String clean=line.trim();if(clean.startsWith("remote ")){String[] parts=clean.split("\\s+");if(parts.length>1)endpoint=parts[1];if(parts.length>2)try{endpointPort=Integer.parseInt(parts[2]);}catch(Exception ignored){}break;}}}host=endpoint;port=endpointPort>0?endpointPort:1194;}String location(){String x=(city+" "+country).trim();return x.isEmpty()?provider:x;}String flag(){return flagEmoji(countryCode(country+" "+city+" "+name));}String key(){return provider+"\n"+name+"\n"+city+"\n"+country;}}
}
